document.write(`
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="icon" href="../img/favicon_64x64.ico" sizes="64x64" type="image/x-icon">
    <link rel="icon" href="../img/favicon_48x48.ico" sizes="48x48" type="image/x-icon">
    <link rel="icon" href="../img/favicon_32x32.ico" sizes="32x32" type="image/x-icon">
    <link rel="icon" href="../img/favicon_16x16.ico" sizes="16x16" type="image/x-icon">

    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/fontawesome-free-web/css/all.css" />        
`);
